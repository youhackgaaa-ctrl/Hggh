/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Plus, 
  Trash2, 
  Edit3, 
  Activity, 
  Trophy, 
  Save, 
  X, 
  LayoutGrid, 
  Zap,
  ArrowLeft,
  Clock
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Match, Sport } from '../types';
import { parseLocalDatetime } from '../utils';

interface AdminProps {
  matches: Match[];
  setMatches: (matches: Match[]) => void;
  onShowToast: (msg: string, type?: 'success' | 'info') => void;
  sports: Sport[];
  setSports: React.Dispatch<React.SetStateAction<Sport[]>>;
}

export default function Admin({ matches, setMatches, onShowToast, sports, setSports }: AdminProps) {
  const navigate = useNavigate();

  const [isAuthed, setIsAuthed] = useState(false);
  const [password, setPassword] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingMatch, setEditingMatch] = useState<Match | null>(null);

  // Sports & Tab management state
  const [activeTab, setActiveTab] = useState<'matches' | 'sports'>('matches');
  const [isSportModalOpen, setIsSportModalOpen] = useState(false);
  const [editingSport, setEditingSport] = useState<Sport | null>(null);
  const [sportFormData, setSportFormData] = useState({
    name: '',
    emoji: '🏆',
    color: '#39FF14',
  });
  const [sportToDeletePending, setSportToDeletePending] = useState<Sport | null>(null);

  // Form State
  const [formData, setFormData] = useState<Partial<Match>>({
    sport: sports[0]?.name || 'Football',
    status: 'upcoming',
    isLive: false,
    teams: {
      home: { name: '', logo: 'https://api.dicebear.com/7.x/identicon/svg?seed=H', score: 0 },
      away: { name: '', logo: 'https://api.dicebear.com/7.x/identicon/svg?seed=A', score: 0 },
    },
    league: '',
    title: '',
    time: "0'",
    videoUrl: '',
    viewers: '0',
    scheduledTime: '',
  });

  const [currentAdminTime, setCurrentAdminTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentAdminTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    const isAdmin = localStorage.getItem('is_admin_authenticated_v2');
    if (isAdmin === 'true') {
      setIsAuthed(true);
    }
  }, []);

  if (!isAuthed) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center p-4">
        <div className="w-full max-w-md bg-gray-900 border border-white/10 rounded-[2.5rem] p-8 shadow-2xl">
          <h2 className="text-2xl font-black mb-6 text-center">Admin Access</h2>
          <input
            type="password"
            placeholder="Enter Admin Password"
            className="w-full h-14 bg-white/5 border border-white/10 rounded-2xl px-6 text-white outline-none focus:border-[#39FF14]/50 mb-4"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <button
            onClick={() => {
              if (password === 'admin123') { // Simple password for now
                localStorage.setItem('is_admin_authenticated_v2', 'true');
                setIsAuthed(true);
              } else {
                onShowToast('Incorrect password', 'info');
              }
            }}
            className="w-full h-14 rounded-2xl bg-[#39FF14] text-black font-black hover:bg-[#32e012] transition-all"
          >
            Access Control Center
          </button>
        </div>
      </div>
    );
  }

  const logout = () => {
    localStorage.removeItem('is_admin_authenticated_v2');
    setIsAuthed(false);
    onShowToast('Logged out', 'info');
  };

  const handleOpenModal = (match?: Match) => {
    if (match) {
      setEditingMatch(match);
      // Ensure scheduledTime is formatted as YYYY-MM-DDTHH:mm for datetime-local input
      let formattedScheduledTime = '';
      if (match.scheduledTime) {
        formattedScheduledTime = match.scheduledTime.replace(' ', 'T');
        if (formattedScheduledTime.length > 16) {
          formattedScheduledTime = formattedScheduledTime.substring(0, 16);
        }
      }
      setFormData({
        ...match,
        scheduledTime: formattedScheduledTime,
        isTvChannel: match.isTvChannel || false
      });
    } else {
      setEditingMatch(null);
      setFormData({
        sport: sports[0]?.name || 'Football',
        status: 'upcoming',
        isLive: false,
        teams: {
          home: { name: '', logo: 'https://api.dicebear.com/7.x/identicon/svg?seed=H' + Math.random(), score: 0 },
          away: { name: '', logo: 'https://api.dicebear.com/7.x/identicon/svg?seed=A' + Math.random(), score: 0 },
        },
        league: '',
        title: '',
        time: "0'",
        videoUrl: '',
        viewers: '0',
        scheduledTime: '',
        isTvChannel: false
      });
    }
    setIsModalOpen(true);
  };

  const handleOpenSportModal = (sport?: Sport) => {
    if (sport) {
      setEditingSport(sport);
      setSportFormData({
        name: sport.name,
        emoji: sport.emoji,
        color: sport.color,
      });
    } else {
      setEditingSport(null);
      setSportFormData({
        name: '',
        emoji: '🏆',
        color: '#39FF14',
      });
    }
    setIsSportModalOpen(true);
  };

  const handleSportSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!sportFormData.name.trim()) return;

    const name = sportFormData.name.trim();
    const id = editingSport ? editingSport.id : name;

    if (!editingSport && sports.some(s => s.name.toLowerCase() === name.toLowerCase())) {
      onShowToast('Sport already exists!', 'info');
      return;
    }

    const newSport: Sport = {
      id,
      name,
      emoji: sportFormData.emoji,
      color: sportFormData.color,
    };

    if (editingSport) {
      const oldName = editingSport.name;
      setSports(sports.map(s => s.id === editingSport.id ? newSport : s));
      setMatches(matches.map(m => m.sport === oldName ? { ...m, sport: name } : m));
      onShowToast('Sport updated successfully!');
    } else {
      setSports([...sports, newSport]);
      onShowToast('Sport added successfully!');
    }

    setIsSportModalOpen(false);
  };

  const handleDeleteSport = (sportToDelete: Sport) => {
    const hasMatches = matches.some(m => m.sport === sportToDelete.name);
    if (hasMatches) {
      onShowToast(`Cannot delete "${sportToDelete.name}". It is used by active matches!`, 'info');
      return;
    }

    setSportToDeletePending(sportToDelete);
  };

  const handleDelete = (id: string) => {
    setMatches(matches.filter(m => m.id !== id));
    onShowToast('Match deleted successfully', 'success');
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        setFormData({
          ...formData,
          teams: {
            ...formData.teams,
            home: {
              name: formData.title || '',
              logo: base64String,
              score: 0
            },
            away: { name: '', logo: '', score: 0 }
          }
        });
        onShowToast('Logo uploaded successfully', 'success');
      };
      reader.readAsDataURL(file);
    }
  };

  const handlePosterUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        setFormData({
          ...formData,
          posterUrl: base64String
        });
        onShowToast('Background picture uploaded successfully', 'success');
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const status = formData.status;
    const isLive = formData.status === 'live';

    const matchData = {
      ...formData,
      id: editingMatch ? editingMatch.id : Math.random().toString(36).substr(2, 9),
      status,
      isLive,
    } as Match;

    if (editingMatch) {
      setMatches(matches.map(m => m.id === editingMatch.id ? matchData : m));
      onShowToast('Match updated successfully');
    } else {
      setMatches([matchData, ...matches]);
      onShowToast('New match added successfully');
    }
    setIsModalOpen(false);
  };

  const updateScore = (matchId: string, team: 'home' | 'away', increment: boolean) => {
    setMatches(matches.map(m => {
      if (m.id === matchId) {
        const newScore = Math.max(0, (m.teams[team].score || 0) + (increment ? 1 : -1));
        return {
          ...m,
          teams: {
            ...m.teams,
            [team]: { ...m.teams[team], score: newScore }
          }
        };
      }
      return m;
    }));
  };

  return (
    <div className="min-h-screen bg-black pt-24 px-4 md:px-8 pb-12">
      <div className="max-w-6xl mx-auto">
        <header className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
          <div>
            <button onClick={() => navigate('/')} className="flex items-center gap-2 text-gray-500 hover:text-white mb-4 transition-colors">
              <ArrowLeft className="w-4 h-4" />
              <span className="text-sm font-bold uppercase tracking-widest">Dashboard</span>
            </button>
            <h1 className="text-4xl font-black tracking-tight flex flex-wrap items-center gap-4">
              Control <span className="text-[#39FF14]">Center</span>
              <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-xs font-bold text-gray-400">
                <Zap className="w-3 h-3 text-[#39FF14]" />
                System Active
              </div>
              <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-xs font-mono font-bold text-gray-400">
                <Clock className="w-3 h-3 text-[#39FF14]" />
                {currentAdminTime.toLocaleTimeString()}
              </div>
            </h1>
            <p className="text-gray-500 mt-2 font-medium">Manage live streams and scheduled matches</p>
          </div>
          
          <div className="flex items-center gap-3">
            <button 
              onClick={logout}
              className="h-14 px-6 rounded-2xl bg-white/5 border border-white/10 text-white font-bold flex items-center gap-2 hover:bg-white/10 transition-all"
            >
              Logout
            </button>
            {activeTab === 'matches' ? (
              <button 
                onClick={() => handleOpenModal()}
                className="h-14 px-8 rounded-2xl bg-[#39FF14] text-black font-black flex items-center gap-3 hover:bg-[#32e012] transition-all transform active:scale-95 shadow-[0_0_30px_rgba(57,255,20,0.2)]"
              >
                <Plus className="w-5 h-5" />
                Add New Match
              </button>
            ) : (
              <button 
                onClick={() => handleOpenSportModal()}
                className="h-14 px-8 rounded-2xl bg-[#39FF14] text-black font-black flex items-center gap-3 hover:bg-[#32e012] transition-all transform active:scale-95 shadow-[0_0_30px_rgba(57,255,20,0.2)]"
              >
                <Plus className="w-5 h-5" />
                Add New Sport
              </button>
            )}
          </div>
        </header>

        {/* Tab Selection */}
        <div className="flex gap-6 border-b border-white/5 mb-8 pb-px">
          <button
            onClick={() => setActiveTab('matches')}
            className={`pb-4 text-sm font-black uppercase tracking-widest border-b-2 transition-all relative ${
              activeTab === 'matches'
                ? 'text-[#39FF14] border-[#39FF14]'
                : 'text-gray-500 hover:text-white border-transparent'
            }`}
          >
            Manage Matches
            <span className="ml-2 px-2 py-0.5 rounded-full bg-white/5 text-[10px] text-gray-400 font-bold">
              {matches.length}
            </span>
          </button>
          <button
            onClick={() => setActiveTab('sports')}
            className={`pb-4 text-sm font-black uppercase tracking-widest border-b-2 transition-all relative ${
              activeTab === 'sports'
                ? 'text-[#39FF14] border-[#39FF14]'
                : 'text-gray-500 hover:text-white border-transparent'
            }`}
          >
            Manage Sports
            <span className="ml-2 px-2 py-0.5 rounded-full bg-white/5 text-[10px] text-gray-400 font-bold">
              {sports.length}
            </span>
          </button>
        </div>

        {activeTab === 'matches' ? (
          /* Dashboard Grid - Matches */
          <div className="grid grid-cols-1 gap-6">
            {matches.map((match) => (
              <motion.div 
                layout
                key={match.id}
                className="p-6 rounded-[2.5rem] bg-white/5 border border-white/10 flex flex-col lg:flex-row lg:items-center justify-between gap-8 group hover:border-[#39FF14]/30 transition-colors"
              >
                <div className="flex items-center gap-6">
                  <div className={`w-16 h-16 rounded-2xl flex items-center justify-center border transition-colors ${
                    match.status === 'live' ? 'bg-[#39FF14]/10 border-[#39FF14]/30' : 'bg-white/5 border-white/10'
                  }`}>
                    <span className="text-2xl">
                      {sports.find(s => s.name === match.sport)?.emoji || '🏆'}
                    </span>
                  </div>
                  <div>
                    <div className="flex items-center gap-3 mb-1">
                      <span className="text-[10px] font-black text-[#39FF14] uppercase tracking-[0.2em]">{match.league}</span>
                      {match.isLive && (
                        <span className="flex items-center gap-1.5 px-2 py-0.5 rounded-md bg-[#39FF14]/10 text-[#39FF14] text-[10px] font-bold">
                          <span className="w-1 h-1 bg-[#39FF14] rounded-full animate-pulse" />
                          LIVE
                        </span>
                      )}
                      {match.isTvChannel && (
                        <span className="flex items-center gap-1.5 px-2 py-0.5 rounded-md bg-red-600/10 text-red-500 text-[10px] font-bold border border-red-500/20">
                          TV
                        </span>
                      )}
                    </div>
                    <h3 className="text-xl font-bold">
                      {match.isTvChannel ? match.title : `${match.teams.home.name} vs ${match.teams.away.name}`}
                    </h3>
                    <p className="text-sm text-gray-500 font-medium">
                      {match.isTvChannel ? 'TV Stream' : match.title} • {match.time} • <span className="text-gray-400 font-bold">{match.sport}</span>
                    </p>
                  </div>
                </div>

                {/* Quick Score Control (Only if Live & Not TV Channel) */}
                {match.status === 'live' && !match.isTvChannel && (
                  <div className="flex items-center gap-8 px-8 py-4 rounded-3xl bg-black/40 border border-white/5">
                    <div className="flex flex-col items-center gap-2">
                      <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">{match.teams.home.name}</span>
                      <div className="flex items-center gap-3">
                        <button onClick={() => updateScore(match.id, 'home', false)} className="w-8 h-8 rounded-lg bg-white/5 hover:bg-white/10 flex items-center justify-center text-white">-</button>
                        <span className="text-2xl font-black text-white">{match.teams.home.score}</span>
                        <button onClick={() => updateScore(match.id, 'home', true)} className="w-8 h-8 rounded-lg bg-white/5 hover:bg-white/10 flex items-center justify-center text-white">+</button>
                      </div>
                    </div>
                    <div className="w-px h-10 bg-white/10" />
                    <div className="flex flex-col items-center gap-2">
                      <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">{match.teams.away.name}</span>
                      <div className="flex items-center gap-3">
                        <button onClick={() => updateScore(match.id, 'away', false)} className="w-8 h-8 rounded-lg bg-white/5 hover:bg-white/10 flex items-center justify-center text-white">-</button>
                        <span className="text-2xl font-black text-white">{match.teams.away.score}</span>
                        <button onClick={() => updateScore(match.id, 'away', true)} className="w-8 h-8 rounded-lg bg-white/5 hover:bg-white/10 flex items-center justify-center text-white">+</button>
                      </div>
                    </div>
                  </div>
                )}

                <div className="flex items-center gap-3">
                  <button 
                    onClick={() => handleOpenModal(match)}
                    className="w-12 h-12 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center text-gray-400 hover:text-white hover:bg-white/10 transition-all"
                  >
                    <Edit3 className="w-5 h-5" />
                  </button>
                  <button 
                    onClick={() => handleDelete(match.id)}
                    className="w-12 h-12 rounded-2xl bg-red-600/10 border border-red-600/20 flex items-center justify-center text-red-600 hover:bg-red-600/20 transition-all"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </motion.div>
            ))}

            {matches.length === 0 && (
              <div className="flex flex-col items-center justify-center py-24 text-gray-500">
                <LayoutGrid className="w-16 h-16 mb-6 opacity-20" />
                <p className="text-xl font-bold">No matches scheduled</p>
                <p className="mt-2">Click "Add New Match" to start broadcasting.</p>
              </div>
            )}
          </div>
        ) : (
          /* Dashboard Grid - Sports */
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {sports.map((sport) => (
              <motion.div
                layout
                key={sport.id}
                className="p-6 rounded-[2.5rem] bg-white/5 border border-white/10 flex items-center justify-between gap-6 group hover:border-[#39FF14]/30 transition-colors"
              >
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center text-2xl select-none">
                    {sport.emoji}
                  </div>
                  <div>
                    <h3 className="font-bold text-white text-lg">{sport.name}</h3>
                    <div className="flex items-center gap-1.5 mt-1">
                      <span className="w-2.5 h-2.5 rounded-full border border-white/20 animate-pulse" style={{ backgroundColor: sport.color }} />
                      <span className="text-xs text-gray-500 font-mono font-medium">{sport.color}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleOpenSportModal(sport)}
                    className="p-3 rounded-xl bg-white/5 border border-white/10 hover:bg-[#39FF14]/10 hover:border-[#39FF14]/30 text-white hover:text-[#39FF14] transition-all"
                    title="Edit Sport"
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleDeleteSport(sport)}
                    className="p-3 rounded-xl bg-white/5 border border-white/10 hover:bg-red-500/10 hover:border-red-500/30 text-white hover:text-red-500 transition-all"
                    title="Delete Sport"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </motion.div>
            ))}

            {sports.length === 0 && (
              <div className="col-span-full flex flex-col items-center justify-center py-24 text-gray-500">
                <LayoutGrid className="w-16 h-16 mb-6 opacity-20" />
                <p className="text-xl font-bold">No sports added</p>
                <p className="mt-2">Click "Add New Sport" to create a new category.</p>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Admin Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsModalOpen(false)}
              className="absolute inset-0 bg-black/80 backdrop-blur-xl" 
            />
            
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative w-full max-w-2xl bg-gray-900 border border-white/10 rounded-[3rem] p-8 md:p-12 shadow-2xl overflow-y-auto max-h-[90vh] custom-scrollbar"
            >
              <div className="flex items-center justify-between mb-8">
                <div>
                  <h2 className="text-3xl font-black tracking-tight">
                    {editingMatch ? 'Edit Match' : 'Add New Match'}
                  </h2>
                  <p className="text-gray-400 mt-1">Configure match details and stream settings</p>
                </div>
                <button onClick={() => setIsModalOpen(false)} className="w-12 h-12 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center">
                  <X className="w-6 h-6" />
                </button>
              </div>

              <form onSubmit={handleSubmit} className="space-y-8">
                {/* Broadcast Type Selector */}
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest ml-4">Broadcast Type</label>
                  <div className="grid grid-cols-2 gap-4 p-1.5 bg-white/5 border border-white/10 rounded-2xl">
                    <button
                      type="button"
                      onClick={() => setFormData({ 
                        ...formData, 
                        isTvChannel: false,
                        sport: formData.sport === 'TV Channel' ? (sports.find(s => s.name !== 'TV Channel')?.name || 'Football') : formData.sport
                      })}
                      className={`h-12 rounded-xl font-bold text-sm transition-all flex items-center justify-center gap-2 ${
                        !formData.isTvChannel 
                          ? 'bg-[#39FF14] text-black shadow-lg font-black' 
                          : 'text-gray-400 hover:text-white hover:bg-white/5'
                      }`}
                    >
                      ⚽ Match / Game
                    </button>
                    <button
                      type="button"
                      onClick={() => setFormData({ 
                        ...formData, 
                        isTvChannel: true,
                        sport: sports.find(s => s.name === 'TV Channel') ? 'TV Channel' : formData.sport
                      })}
                      className={`h-12 rounded-xl font-bold text-sm transition-all flex items-center justify-center gap-2 ${
                        formData.isTvChannel 
                          ? 'bg-[#39FF14] text-black shadow-lg font-black' 
                          : 'text-gray-400 hover:text-white hover:bg-white/5'
                      }`}
                    >
                      📺 TV Channel
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest ml-4">Sport Type</label>
                    <select 
                      className="w-full h-14 bg-white/5 border border-white/10 rounded-2xl px-6 text-white outline-none focus:border-[#39FF14]/50"
                      value={formData.sport}
                      onChange={(e) => setFormData({...formData, sport: e.target.value})}
                    >
                      {sports.map((sport) => (
                        <option key={sport.id} value={sport.name}>{sport.name}</option>
                      ))}
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest ml-4">Current Status</label>
                    <select 
                      className="w-full h-14 bg-white/5 border border-white/10 rounded-2xl px-6 text-white outline-none focus:border-[#39FF14]/50"
                      value={formData.status}
                      onChange={(e) => setFormData({...formData, status: e.target.value as 'live' | 'upcoming'})}
                    >
                      <option value="live">Live Stream</option>
                      <option value="upcoming">Upcoming Match</option>
                    </select>
                  </div>
                </div>

                {formData.isTvChannel ? (
                  /* TV Channel specific fields */
                  <div className="space-y-6">
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest ml-4">Network Name / Category (e.g. Sony SIX, Sky Sports)</label>
                      <input 
                        type="text" 
                        placeholder="e.g. Sky Sports Football"
                        className="w-full h-14 bg-white/5 border border-white/10 rounded-2xl px-6 text-white outline-none focus:border-[#39FF14]/50"
                        value={formData.league || ''}
                        onChange={(e) => setFormData({...formData, league: e.target.value})}
                        required={formData.isTvChannel}
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest ml-4">Channel Name / Title</label>
                        <input 
                          type="text" 
                          placeholder="e.g. Sky Sports Live HD"
                          className="w-full h-14 bg-white/5 border border-white/10 rounded-2xl px-6 text-white outline-none focus:border-[#39FF14]/50"
                          value={formData.title || ''}
                          onChange={(e) => setFormData({
                            ...formData, 
                            title: e.target.value,
                            teams: {
                              home: { name: e.target.value, logo: formData.teams?.home?.logo || `https://api.dicebear.com/7.x/identicon/svg?seed=${e.target.value}`, score: 0 },
                              away: { name: '', logo: '', score: 0 }
                            }
                          })}
                          required={formData.isTvChannel}
                        />
                      </div>

                      <div className="space-y-2 flex flex-col">
                        <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest ml-4">Channel Logo URL</label>
                        <input 
                          type="text" 
                          placeholder="https://example.com/logo.png"
                          className="w-full h-14 bg-white/5 border border-white/10 rounded-2xl px-6 text-white outline-none focus:border-[#39FF14]/50"
                          value={formData.teams?.home?.logo || ''}
                          onChange={(e) => setFormData({
                            ...formData,
                            teams: {
                              home: {
                                name: formData.title || '',
                                logo: e.target.value,
                                score: 0
                              },
                              away: { name: '', logo: '', score: 0 }
                            }
                          })}
                        />
                        <div className="mt-2 flex items-center gap-3">
                          <label className="cursor-pointer px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs text-gray-300 hover:text-white transition-all font-bold flex items-center gap-2">
                            <span>Upload Logo Image</span>
                            <input 
                              type="file" 
                              accept="image/*" 
                              className="hidden" 
                              onChange={handleLogoUpload} 
                            />
                          </label>
                          {formData.teams?.home?.logo && (
                            <img 
                              src={formData.teams.home.logo} 
                              alt="Logo Preview" 
                              className="w-8 h-8 rounded-lg object-contain bg-black/40 p-1 border border-white/10" 
                            />
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2 flex flex-col">
                      <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest ml-4">Channel Background / Poster URL (e.g. Gopal Bhar bg poster)</label>
                      <input 
                        type="text" 
                        placeholder="https://example.com/gopal_bhar_bg.png"
                        className="w-full h-14 bg-white/5 border border-white/10 rounded-2xl px-6 text-white outline-none focus:border-[#39FF14]/50"
                        value={formData.posterUrl || ''}
                        onChange={(e) => setFormData({
                          ...formData,
                          posterUrl: e.target.value
                        })}
                      />
                      <div className="mt-2 flex items-center gap-3">
                        <label className="cursor-pointer px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs text-gray-300 hover:text-white transition-all font-bold flex items-center gap-2">
                          <span>Upload Background picture</span>
                          <input 
                            type="file" 
                            accept="image/*" 
                            className="hidden" 
                            onChange={handlePosterUpload} 
                          />
                        </label>
                        {formData.posterUrl && (
                          <img 
                            src={formData.posterUrl} 
                            alt="Background Preview" 
                            className="w-16 h-9 rounded-lg object-cover bg-black/40 border border-white/10" 
                          />
                        )}
                      </div>
                    </div>
                  </div>
                ) : (
                  /* Match / Game specific fields */
                  <div className="space-y-6">
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest ml-4">League Name</label>
                      <input 
                        type="text" 
                        placeholder="e.g. Champions League"
                        className="w-full h-14 bg-white/5 border border-white/10 rounded-2xl px-6 text-white outline-none focus:border-[#39FF14]/50"
                        value={formData.league || ''}
                        onChange={(e) => setFormData({...formData, league: e.target.value})}
                        required={!formData.isTvChannel}
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      {/* Home Team */}
                      <div className="p-6 rounded-[2rem] bg-white/5 border border-white/5 space-y-4">
                        <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Home Team</span>
                        <input 
                          type="text" 
                          placeholder="Team Name"
                          className="w-full h-12 bg-black/40 border border-white/10 rounded-xl px-4 text-sm text-white outline-none"
                          value={formData.teams?.home?.name || ''}
                          onChange={(e) => setFormData({
                            ...formData, 
                            teams: {
                              home: {
                                name: e.target.value,
                                logo: formData.teams?.home?.logo || `https://api.dicebear.com/7.x/identicon/svg?seed=H${Math.random()}`,
                                score: formData.teams?.home?.score ?? 0
                              },
                              away: {
                                name: formData.teams?.away?.name || '',
                                logo: formData.teams?.away?.logo || `https://api.dicebear.com/7.x/identicon/svg?seed=A${Math.random()}`,
                                score: formData.teams?.away?.score ?? 0
                              }
                            }
                          })}
                          required={!formData.isTvChannel}
                        />
                        <div className="flex items-center gap-3">
                          <input 
                            type="number" 
                            placeholder="Score"
                            className="w-24 h-12 bg-black/40 border border-white/10 rounded-xl px-4 text-sm text-white outline-none"
                            value={formData.teams?.home?.score ?? ''}
                            onChange={(e) => setFormData({
                              ...formData, 
                              teams: {
                                home: {
                                  name: formData.teams?.home?.name || '',
                                  logo: formData.teams?.home?.logo || `https://api.dicebear.com/7.x/identicon/svg?seed=H${Math.random()}`,
                                  score: parseInt(e.target.value) || 0
                                },
                                away: {
                                  name: formData.teams?.away?.name || '',
                                  logo: formData.teams?.away?.logo || `https://api.dicebear.com/7.x/identicon/svg?seed=A${Math.random()}`,
                                  score: formData.teams?.away?.score ?? 0
                                }
                              }
                            })}
                          />
                          <span className="text-xs text-gray-500 font-bold">Points/Goals</span>
                        </div>
                      </div>

                      {/* Away Team */}
                      <div className="p-6 rounded-[2rem] bg-white/5 border border-white/5 space-y-4">
                        <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Away Team</span>
                        <input 
                          type="text" 
                          placeholder="Team Name"
                          className="w-full h-12 bg-black/40 border border-white/10 rounded-xl px-4 text-sm text-white outline-none"
                          value={formData.teams?.away?.name || ''}
                          onChange={(e) => setFormData({
                            ...formData, 
                            teams: {
                              home: {
                                name: formData.teams?.home?.name || '',
                                logo: formData.teams?.home?.logo || `https://api.dicebear.com/7.x/identicon/svg?seed=H${Math.random()}`,
                                score: formData.teams?.home?.score ?? 0
                              },
                              away: {
                                name: e.target.value,
                                logo: formData.teams?.away?.logo || `https://api.dicebear.com/7.x/identicon/svg?seed=A${Math.random()}`,
                                score: formData.teams?.away?.score ?? 0
                              }
                            }
                          })}
                          required={!formData.isTvChannel}
                        />
                        <div className="flex items-center gap-3">
                          <input 
                            type="number" 
                            placeholder="Score"
                            className="w-24 h-12 bg-black/40 border border-white/10 rounded-xl px-4 text-sm text-white outline-none"
                            value={formData.teams?.away?.score ?? ''}
                            onChange={(e) => setFormData({
                              ...formData, 
                              teams: {
                                home: {
                                  name: formData.teams?.home?.name || '',
                                  logo: formData.teams?.home?.logo || `https://api.dicebear.com/7.x/identicon/svg?seed=H${Math.random()}`,
                                  score: formData.teams?.home?.score ?? 0
                                },
                                away: {
                                  name: formData.teams?.away?.name || '',
                                  logo: formData.teams?.away?.logo || `https://api.dicebear.com/7.x/identicon/svg?seed=A${Math.random()}`,
                                  score: parseInt(e.target.value) || 0
                                }
                              }
                            })}
                          />
                          <span className="text-xs text-gray-500 font-bold">Points/Goals</span>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest ml-4">Match Description</label>
                      <input 
                        type="text" 
                        placeholder="e.g. Round 16"
                        className="w-full h-14 bg-white/5 border border-white/10 rounded-2xl px-6 text-white outline-none focus:border-[#39FF14]/50"
                        value={formData.title || ''}
                        onChange={(e) => setFormData({...formData, title: e.target.value})}
                        required={!formData.isTvChannel}
                      />
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest ml-4">
                      {formData.isTvChannel ? "Status Text / Airing Program" : "Current Match Clock (e.g. 45', HT)"}
                    </label>
                    <input 
                      type="text" 
                      placeholder={formData.isTvChannel ? "e.g. LIVE, 24/7, or Program Name" : "e.g. 78', HT, or 'Upcoming'"}
                      className="w-full h-14 bg-white/5 border border-white/10 rounded-2xl px-6 text-white outline-none focus:border-[#39FF14]/50"
                      value={formData.time || ''}
                      onChange={(e) => setFormData({...formData, time: e.target.value})}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest ml-4">Viewers Count</label>
                    <input 
                      type="text" 
                      placeholder="e.g. 1.2M or 50K"
                      className="w-full h-14 bg-white/5 border border-white/10 rounded-2xl px-6 text-white outline-none focus:border-[#39FF14]/50"
                      value={formData.viewers || ''}
                      onChange={(e) => setFormData({...formData, viewers: e.target.value})}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest ml-4">Live Video URL (YouTube Embed or direct link)</label>
                  <input 
                    type="text" 
                    placeholder="https://www.youtube.com/embed/..."
                    className="w-full h-14 bg-white/5 border border-white/10 rounded-2xl px-6 text-white outline-none focus:border-[#39FF14]/50"
                    value={formData.videoUrl || ''}
                    onChange={(e) => setFormData({...formData, videoUrl: e.target.value})}
                  />
                  <p className="text-[10px] text-gray-500 ml-4 italic">Leave empty to use default sport placeholder image</p>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between items-center px-4">
                    <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Scheduled Start Date & Time</label>
                    <span className="text-[10px] font-mono font-bold text-[#39FF14] flex items-center gap-1.5 bg-white/5 border border-white/10 px-2.5 py-1 rounded-full">
                      <Clock className="w-3 h-3" />
                      Now: {currentAdminTime.toLocaleTimeString()}
                    </span>
                  </div>
                  <input 
                    type="datetime-local" 
                    className="w-full h-14 bg-white/5 border border-white/10 rounded-2xl px-6 text-white outline-none focus:border-[#39FF14]/50 [color-scheme:dark]"
                    value={formData.scheduledTime || ''}
                    onChange={(e) => setFormData({...formData, scheduledTime: e.target.value})}
                  />
                  <p className="text-[10px] text-gray-500 ml-4 italic">Setting this creates a countdown. Match goes LIVE automatically at this exact time.</p>
                </div>

                <div className="pt-4 flex items-center gap-4">
                  <button 
                    type="submit"
                    className="flex-1 h-16 rounded-[1.5rem] bg-[#39FF14] text-black font-black flex items-center justify-center gap-3 hover:bg-[#32e012] transition-all transform active:scale-95 shadow-[0_0_40px_rgba(57,255,20,0.2)]"
                  >
                    <Save className="w-5 h-5" />
                    {editingMatch ? 'Update Match' : 'Launch Match'}
                  </button>
                  <button 
                    type="button"
                    onClick={() => setIsModalOpen(false)}
                    className="flex-1 h-16 rounded-[1.5rem] bg-white/5 border border-white/10 text-white font-bold hover:bg-white/10 transition-all"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Sport Modal */}
      <AnimatePresence>
        {isSportModalOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsSportModalOpen(false)}
              className="absolute inset-0 bg-black/80 backdrop-blur-xl" 
            />
            
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative w-full max-w-md bg-gray-900 border border-white/10 rounded-[3rem] p-8 md:p-10 shadow-2xl overflow-y-auto max-h-[90vh] custom-scrollbar"
            >
              <div className="flex items-center justify-between mb-8">
                <div>
                  <h2 className="text-2xl font-black tracking-tight">
                    {editingSport ? 'Edit Sport' : 'Add New Sport'}
                  </h2>
                  <p className="text-sm text-gray-500 font-medium">Configure sport category details</p>
                </div>
                <button 
                  onClick={() => setIsSportModalOpen(false)}
                  className="w-12 h-12 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center text-gray-400 hover:text-white transition-all hover:bg-white/10"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <form onSubmit={handleSportSubmit} className="space-y-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest ml-4">Sport Name</label>
                  <input 
                    type="text" 
                    placeholder="e.g. Football or Tennis"
                    className="w-full h-14 bg-white/5 border border-white/10 rounded-2xl px-6 text-white outline-none focus:border-[#39FF14]/50"
                    value={sportFormData.name}
                    onChange={(e) => setSportFormData({...sportFormData, name: e.target.value})}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest ml-4">Sport Emoji</label>
                  <div className="flex gap-4">
                    <input 
                      type="text" 
                      placeholder="🏆"
                      maxLength={2}
                      className="w-20 h-14 bg-white/5 border border-white/10 rounded-2xl text-center text-2xl text-white outline-none focus:border-[#39FF14]/50"
                      value={sportFormData.emoji}
                      onChange={(e) => setSportFormData({...sportFormData, emoji: e.target.value})}
                      required
                    />
                    <div className="flex-1 text-xs text-gray-500 flex items-center">
                      Select or type any custom emoji to represent this sport category.
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2 mt-3 p-3 rounded-2xl bg-black/40 border border-white/5">
                    {['⚽', '🏏', '🏀', '🎾', '🏈', '🏐', '🏓', '🏸', '🏎️', '🥊', '🏆', '🏄', '🏌️', '🚴', '🎮'].map(emoji => (
                      <button
                        key={emoji}
                        type="button"
                        onClick={() => setSportFormData({ ...sportFormData, emoji })}
                        className={`w-10 h-10 rounded-xl flex items-center justify-center text-xl transition-all ${
                          sportFormData.emoji === emoji 
                            ? 'bg-[#39FF14]/20 border border-[#39FF14]/50 scale-110' 
                            : 'bg-white/5 border border-white/10 hover:bg-white/10'
                        }`}
                      >
                        {emoji}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest ml-4">Theme Color</label>
                  <div className="flex gap-4 items-center">
                    <input 
                      type="color" 
                      className="w-14 h-14 bg-transparent border-0 outline-none cursor-pointer rounded-2xl overflow-hidden [&::-webkit-color-swatch-wrapper]:p-0 [&::-webkit-color-swatch]:border-0 [&::-webkit-color-swatch]:rounded-2xl"
                      value={sportFormData.color}
                      onChange={(e) => setSportFormData({...sportFormData, color: e.target.value})}
                    />
                    <input 
                      type="text" 
                      className="flex-1 h-14 bg-white/5 border border-white/10 rounded-2xl px-6 text-white font-mono uppercase text-sm outline-none focus:border-[#39FF14]/50"
                      value={sportFormData.color}
                      onChange={(e) => setSportFormData({...sportFormData, color: e.target.value})}
                      required
                    />
                  </div>
                </div>

                <div className="pt-4 flex items-center gap-4">
                  <button 
                    type="submit"
                    className="flex-1 h-16 rounded-[1.5rem] bg-[#39FF14] text-black font-black flex items-center justify-center gap-3 hover:bg-[#32e012] transition-all transform active:scale-95 shadow-[0_0_40px_rgba(57,255,20,0.2)]"
                  >
                    <Save className="w-5 h-5" />
                    {editingSport ? 'Save Changes' : 'Create Sport'}
                  </button>
                  <button 
                    type="button"
                    onClick={() => setIsSportModalOpen(false)}
                    className="flex-1 h-16 rounded-[1.5rem] bg-white/5 border border-white/10 text-white font-bold hover:bg-white/10 transition-all"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Delete Confirmation Modal */}
      <AnimatePresence>
        {sportToDeletePending && (
          <div className="fixed inset-0 z-[110] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSportToDeletePending(null)}
              className="absolute inset-0 bg-black/80 backdrop-blur-md" 
            />
            
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative w-full max-w-sm bg-gray-950 border border-white/10 rounded-[2.5rem] p-8 shadow-2xl text-center z-10"
            >
              <div className="w-16 h-16 rounded-full bg-red-500/10 border border-red-500/20 flex items-center justify-center mx-auto mb-6 text-red-500 text-3xl">
                ⚠️
              </div>
              <h3 className="text-xl font-bold mb-2">Delete Sport?</h3>
              <p className="text-sm text-gray-400 mb-8">
                Are you sure you want to delete <span className="text-white font-bold">{sportToDeletePending.name}</span>? This action cannot be undone.
              </p>

              <div className="flex gap-4">
                <button 
                  onClick={() => {
                    setSports(sports.filter(s => s.id !== sportToDeletePending.id));
                    onShowToast('Sport deleted successfully!', 'success');
                    setSportToDeletePending(null);
                  }}
                  className="flex-1 h-14 rounded-2xl bg-red-600 hover:bg-red-700 text-white font-bold transition-all transform active:scale-95"
                >
                  Delete
                </button>
                <button 
                  type="button"
                  onClick={() => setSportToDeletePending(null)}
                  className="flex-1 h-14 rounded-2xl bg-white/5 border border-white/10 text-white font-bold hover:bg-white/10 transition-all"
                >
                  Cancel
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
