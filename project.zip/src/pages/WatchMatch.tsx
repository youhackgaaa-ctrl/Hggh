/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { ArrowLeft, Users, Share2, Maximize, Volume2, Play, Pause, Settings, Trophy } from 'lucide-react';
import { LIVE_MATCHES } from '../data';
import { Match } from '../types';
import Header from '../components/Header';
import HlsPlayer from '../components/HlsPlayer';
import { useState, useEffect } from 'react';
import { parseLocalDatetime } from '../utils';

interface WatchMatchProps {
  matches: Match[];
}

export default function WatchMatch({ matches }: WatchMatchProps) {
  const { id } = useParams();
  const navigate = useNavigate();
  const liveMatches = matches.filter(m => m.status === 'live');
  const match = matches.find(m => m.id === id) || liveMatches[0];
  const [isPlaying, setIsPlaying] = useState(true);
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const getEmbedUrl = (url: string) => {
    if (!url) return '';
    if (url.includes('youtube.com') || url.includes('youtu.be')) {
      const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=|live\/)([^#&?]*).*/;
      const match = url.match(regExp);
      const videoId = (match && match[2].length === 11) ? match[2] : null;
      if (videoId) return `https://www.youtube.com/embed/${videoId}`;
    }
    return url;
  };

  return (
    <div className="min-h-screen bg-black text-white font-sans selection:bg-[#39FF14] selection:text-black relative overflow-hidden">
      {/* Ambient background blurred backdrop */}
      {match?.posterUrl && (
        <div className="absolute inset-0 pointer-events-none overflow-hidden z-0 opacity-40">
          <img 
            src={match.posterUrl} 
            alt="" 
            className="w-full h-full object-cover scale-110 blur-[80px]" 
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-black/85" />
        </div>
      )}
      <Header onSearch={() => {}} onShowToast={() => {}} />

      <main className="pt-24 px-4 md:px-8 max-w-[1600px] mx-auto relative z-10">
        {/* Back Button */}
        <button 
          onClick={() => navigate('/')}
          className="flex items-center gap-2 text-gray-400 hover:text-white mb-6 transition-colors group"
        >
          <ArrowLeft className="w-4 h-4 transition-transform group-hover:-translate-x-1" />
          <span className="text-sm font-bold">Back to Dashboard</span>
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Main Player Area */}
          <div className="lg:col-span-8 space-y-6">
            <div className="relative aspect-video rounded-[2.5rem] overflow-hidden bg-gray-900 border border-white/10 group shadow-2xl">
              {!match.isLive ? (
                <div className="absolute inset-0 flex flex-col items-center justify-center p-8 text-center relative">
                  {match.posterUrl && (
                    <div className="absolute inset-0 z-0">
                      <img 
                        src={match.posterUrl} 
                        alt="" 
                        className="w-full h-full object-cover opacity-30" 
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-black" />
                    </div>
                  )}
                  <div className="relative z-10 flex flex-col items-center w-full">
                    <div className="w-20 h-20 rounded-full bg-[#39FF14]/10 flex items-center justify-center mb-6 animate-pulse">
                      <Trophy className="w-10 h-10 text-[#39FF14]" />
                    </div>
                    
                    {match.scheduledTime && parseLocalDatetime(match.scheduledTime) > currentTime ? (
                      <>
                        <h2 className="text-3xl font-black mb-2 uppercase tracking-tighter">Match Hasn't Started Yet</h2>
                        <p className="text-gray-400 font-bold mb-8 uppercase tracking-widest text-xs">Stay tuned! The match will begin soon.</p>
                        
                        <div className="grid grid-cols-4 gap-4 max-w-sm w-full">
                          {[
                            { label: 'Days', value: Math.max(0, Math.floor((parseLocalDatetime(match.scheduledTime).getTime() - currentTime.getTime()) / (1000 * 60 * 60 * 24))) },
                            { label: 'Hours', value: Math.max(0, Math.floor(((parseLocalDatetime(match.scheduledTime).getTime() - currentTime.getTime()) / (1000 * 60 * 60)) % 24)) },
                            { label: 'Mins', value: Math.max(0, Math.floor(((parseLocalDatetime(match.scheduledTime).getTime() - currentTime.getTime()) / (1000 * 60)) % 60)) },
                            { label: 'Secs', value: Math.max(0, Math.floor(((parseLocalDatetime(match.scheduledTime).getTime() - currentTime.getTime()) / 1000) % 60)) }
                          ].map((unit, i) => (
                            <div key={i} className="flex flex-col items-center p-3 rounded-2xl bg-white/5 border border-white/10">
                              <span className="text-xl font-black text-[#39FF14]">{unit.value.toString().padStart(2, '0')}</span>
                              <span className="text-[8px] font-bold text-gray-500 uppercase">{unit.label}</span>
                            </div>
                          ))}
                        </div>

                        <div className="mt-8 px-6 py-3 rounded-full bg-white/5 border border-white/10 flex items-center gap-3">
                          <div className="w-2 h-2 rounded-full bg-[#00D4FF] animate-pulse" />
                          <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">
                            Scheduled for {parseLocalDatetime(match.scheduledTime).toLocaleString()}
                          </span>
                        </div>
                      </>
                    ) : (
                      <>
                        <h2 className="text-3xl font-black mb-2 uppercase tracking-tighter">Starting Soon</h2>
                        <p className="text-gray-400 font-bold mb-8 uppercase tracking-widest text-xs">The countdown has finished. Waiting for the broadcast to begin.</p>
                      </>
                    )}
                  </div>
                </div>
              ) : match.videoUrl ? (
                match.videoUrl.includes('.m3u8') ? (
                  <HlsPlayer url={match.videoUrl} />
                ) : (
                  <iframe 
                    src={getEmbedUrl(match.videoUrl)}
                    className="w-full h-full border-none"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  />
                )
              ) : (
                <>
                  {/* Mock Video Content */}
                  <img 
                    src={match.posterUrl || (match.isTvChannel 
                      ? "https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?q=80&w=2070&auto=format&fit=crop"
                      : (match.sport === 'Cricket' 
                        ? "https://images.unsplash.com/photo-1531415074941-03f6ad88997b?q=80&w=2070&auto=format&fit=crop"
                        : "https://images.unsplash.com/photo-1574629810360-7efbbe195018?q=80&w=2070&auto=format&fit=crop"
                      )
                    )}
                    className="w-full h-full object-cover opacity-60"
                    alt="Live Stream"
                  />

                  {/* Player Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <div className="absolute inset-x-0 bottom-0 p-8">
                      <div className="flex flex-col gap-6">
                        {/* Progress Bar */}
                        <div className="w-full h-1 bg-white/20 rounded-full overflow-hidden">
                          <div className="w-3/4 h-full bg-[#39FF14] shadow-[0_0_10px_rgba(57,255,20,0.5)]" />
                        </div>

                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-6">
                            <button onClick={() => setIsPlaying(!isPlaying)} className="text-white hover:text-[#39FF14] transition-colors">
                              {isPlaying ? <Pause className="w-8 h-8 fill-current" /> : <Play className="w-8 h-8 fill-current" />}
                            </button>
                            <div className="flex items-center gap-4">
                              <Volume2 className="w-5 h-5" />
                              <span className="text-xs font-bold tracking-widest uppercase">720p HD • LIVE</span>
                            </div>
                          </div>
                          <div className="flex items-center gap-6">
                            <Settings className="w-5 h-5 hover:rotate-90 transition-transform duration-500" />
                            <Maximize className="w-5 h-5" />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </>
              )}

              {/* Live Badge */}
              {match.isLive && (
                <div className="absolute top-6 left-6 flex items-center gap-2 px-3 py-1.5 rounded-full bg-red-600 border border-white/20">
                  <div className="w-1.5 h-1.5 bg-white rounded-full animate-pulse" />
                  <span className="text-[10px] font-black uppercase tracking-wider">Live</span>
                </div>
              )}
            </div>

            {/* Match Info */}
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 p-8 rounded-[2.5rem] bg-white/5 border border-white/10">
              {match.isTvChannel ? (
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center p-2">
                    <img 
                      src={match.teams?.home?.logo || "https://api.dicebear.com/7.x/identicon/svg?seed=TV"} 
                      className="w-full h-full object-contain" 
                      alt={match.title} 
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div className="flex flex-col">
                    <div className="flex items-center gap-2">
                      <span className="px-2.5 py-0.5 rounded-md bg-red-600/10 border border-red-600/20 text-red-600 text-[10px] font-black uppercase tracking-wider">TV Channel</span>
                      <span className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">{match.league || 'LIVE'}</span>
                    </div>
                    <h2 className="text-2xl font-black mt-1 text-white">{match.title}</h2>
                  </div>
                </div>
              ) : (
                <div className="flex items-center gap-8">
                  <div className="flex items-center gap-4">
                    <img src={match.teams.home.logo} className="w-12 h-12" alt={match.teams.home.name} referrerPolicy="no-referrer" />
                    <div className="flex flex-col">
                      <span className="text-xs text-gray-500 font-bold uppercase tracking-tight">{match.teams.home.name}</span>
                    </div>
                  </div>
                  <div className="text-gray-600 font-black text-xl">VS</div>
                  <div className="flex items-center gap-4">
                    <div className="flex flex-col items-end">
                      <span className="text-xs text-gray-500 font-bold uppercase tracking-tight">{match.teams.away.name}</span>
                    </div>
                    <img src={match.teams.away.logo} className="w-12 h-12" alt={match.teams.away.name} referrerPolicy="no-referrer" />
                  </div>
                </div>
              )}

              <div className="flex items-center gap-4">
                <button className="flex items-center gap-2 px-6 py-3 rounded-2xl bg-white/5 border border-white/10 text-white font-bold hover:bg-white/10 transition-all">
                  <Share2 className="w-4 h-4" />
                  Share
                </button>
                {!match.isTvChannel && (
                  <button className="flex items-center gap-2 px-6 py-3 rounded-2xl bg-[#39FF14] text-black font-black hover:bg-[#32e012] transition-all">
                    <Trophy className="w-4 h-4" />
                    Bet Now
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Sidebar Area: Stats & Suggested */}
          <div className="lg:col-span-4 space-y-8">
            <div className="p-8 rounded-[2.5rem] bg-white/5 border border-white/10">
              <div className="flex items-center justify-between">
                <h3 className="font-black text-lg">Live Audience</h3>
                <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10">
                  <Users className="w-3 h-3 text-[#00D4FF]" />
                  <span className="text-[10px] font-bold text-gray-300">{match.viewers || '0'} watching</span>
                </div>
              </div>
            </div>
 
            {/* Suggested Matches */}
            <div className="space-y-4">
              <h3 className="font-black text-sm uppercase tracking-widest text-gray-500 ml-4">Other Live Events</h3>
              {liveMatches.filter(m => m.id !== id).map(m => (
                <div key={m.id} onClick={() => navigate(`/watch/${m.id}`)} className="p-4 rounded-3xl bg-white/5 border border-white/5 hover:border-white/20 transition-all cursor-pointer group">
                  <div className="flex items-center gap-4">
                    {m.isTvChannel ? (
                      <div className="w-10 h-10 rounded-xl bg-black border border-white/10 p-1.5 flex items-center justify-center">
                        <img src={m.teams?.home?.logo || "https://api.dicebear.com/7.x/identicon/svg?seed=TV"} className="w-full h-full object-contain" alt="" referrerPolicy="no-referrer" />
                      </div>
                    ) : (
                      <div className="flex -space-x-3">
                        <img src={m.teams.home.logo} className="w-10 h-10 rounded-xl bg-black border border-white/10 p-1" alt="" referrerPolicy="no-referrer" />
                        <img src={m.teams.away.logo} className="w-10 h-10 rounded-xl bg-black border border-white/10 p-1" alt="" referrerPolicy="no-referrer" />
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <h4 className="text-sm font-bold truncate">
                        {m.isTvChannel ? m.title : `${m.teams.home.name} vs ${m.teams.away.name}`}
                      </h4>
                      <p className="text-[10px] text-gray-500 font-bold uppercase truncate">
                        {m.isTvChannel ? 'TV CHANNEL' : m.league}
                      </p>
                    </div>
                    <div className="flex items-center gap-2 px-2 py-1 rounded-lg bg-red-600/10 border border-red-600/20 text-red-600 text-[10px] font-black">
                      LIVE
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
