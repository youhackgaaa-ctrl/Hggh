/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ChevronRight, Play, Trophy, Activity } from 'lucide-react';
import { motion } from 'motion/react';
import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import Sidebar from '../components/Sidebar';
import MatchCard from '../components/MatchCard';
import { LIVE_MATCHES, UPCOMING_MATCHES } from '../data';
import { Match, Sport } from '../types';

interface HomeProps {
  searchQuery: string;
  onShowToast: (msg: string, type?: 'success' | 'info') => void;
  matches: Match[];
  sports: Sport[];
}

export default function Home({ searchQuery, onShowToast, matches, sports }: HomeProps) {
  const [activeSport, setActiveSport] = useState('All Sports');
  const navigate = useNavigate();

  const liveMatches = matches.filter(m => m.status === 'live');
  const upcomingMatches = matches.filter(m => m.status === 'upcoming');
  const featuredMatch = liveMatches[0] || upcomingMatches[0];

  const filteredLiveMatches = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();
    return liveMatches.filter((m) => {
      // 1. Check Search Matching (Search title, teams, sport, etc.)
      const matchesSearch = m.title.toLowerCase().includes(query) || 
                           m.teams.home.name.toLowerCase().includes(query) ||
                           m.teams.away.name.toLowerCase().includes(query) ||
                           (m.sport && m.sport.toLowerCase().includes(query));

      // If search query is entered, match purely based on the search query across all items (including TV Channels)
      if (query.length > 0) {
        return matchesSearch;
      }

      // 2. Filter by Active Sport Category as normal
      if (activeSport === 'TV Channel') {
        // Only show TV Channels
        if (!m.isTvChannel && m.sport !== 'TV Channel') return false;
      } else {
        // For any other category, completely hide TV Channels
        if (m.isTvChannel || m.sport === 'TV Channel') return false;

        if (activeSport === 'All Sports' || activeSport === 'live') {
          // "all sports e sudo football and cricket deka jai"
          if (m.sport !== 'Football' && m.sport !== 'Cricket') return false;
        } else if (activeSport === 'fav') {
          // Keep favorites but exclude TV channels (handled above)
        } else {
          // Specific sport selection
          if (m.sport !== activeSport) return false;
        }
      }

      return true;
    });
  }, [activeSport, searchQuery, liveMatches]);

  const filteredUpcomingMatches = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();
    return upcomingMatches.filter((m) => {
      // 1. Check Search Matching (Search title, teams, sport, etc.)
      const matchesSearch = m.title.toLowerCase().includes(query) || 
                           m.teams.home.name.toLowerCase().includes(query) ||
                           m.teams.away.name.toLowerCase().includes(query) ||
                           (m.sport && m.sport.toLowerCase().includes(query));

      // If search query is entered, match purely based on the search query across all items (including TV Channels)
      if (query.length > 0) {
        return matchesSearch;
      }

      // 2. Filter by Active Sport Category
      if (activeSport === 'TV Channel') {
        // Only show TV Channels
        if (!m.isTvChannel && m.sport !== 'TV Channel') return false;
      } else {
        // For any other category, completely hide TV Channels
        if (m.isTvChannel || m.sport === 'TV Channel') return false;

        if (activeSport === 'All Sports' || activeSport === 'upcoming') {
          // "all sports e sudo football and cricket deka jai"
          if (m.sport !== 'Football' && m.sport !== 'Cricket') return false;
        } else {
          if (m.sport !== activeSport) return false;
        }
      }

      return true;
    });
  }, [activeSport, searchQuery, upcomingMatches]);

  return (
    <div className="flex">
      <Sidebar activeSport={activeSport} onSportChange={setActiveSport} sports={sports} />
      
      <main className="flex-1 xl:ml-72 px-4 md:px-8 py-8 overflow-x-hidden">
        {/* Hero / Featured Section */}
        <section className="mb-12 relative rounded-[2.5rem] overflow-hidden border border-white/5 aspect-[21/9] min-h-[300px]">
          <div className="absolute inset-0 bg-gradient-to-r from-black via-black/40 to-transparent z-10" />
          <img 
            src="https://images.unsplash.com/photo-1508098682722-e99c43a406b2?q=80&w=2070&auto=format&fit=crop" 
            alt="Featured Match"
            className="absolute inset-0 w-full h-full object-cover opacity-60 scale-105"
          />
          
          <div className="absolute inset-0 z-20 p-8 md:p-12 flex flex-col justify-center max-w-2xl">
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex items-center gap-2 mb-6"
            >
              <span className="px-3 py-1 rounded-full bg-[#39FF14] text-black text-[10px] font-black uppercase tracking-widest">
                Match of the Day
              </span>
              <span className="flex items-center gap-1.5 text-xs text-gray-300 font-bold">
                <Activity className="w-3 h-3 text-[#39FF14]" />
                98.2K Watching
              </span>
            </motion.div>
            
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="text-4xl md:text-6xl font-black mb-6 leading-[1.1] tracking-tight"
            >
              UEFA Champions League <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#39FF14] to-[#00D4FF]">
                Final Showdown
              </span>
            </motion.h1>
            
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
              className="flex items-center gap-4"
            >
              <button 
                onClick={() => {
                  if (featuredMatch) {
                    onShowToast('Starting 4K Stream Buffer...');
                    navigate(`/watch/${featuredMatch.id}`);
                  } else {
                    onShowToast('No featured event currently live.', 'info');
                  }
                }}
                className="h-14 px-8 rounded-2xl bg-[#39FF14] text-black font-black flex items-center gap-3 hover:bg-[#32e012] transition-all transform active:scale-95 shadow-[0_0_30px_rgba(57,255,20,0.3)]"
              >
                <Play className="w-5 h-5 fill-current" />
                Stream in 4K
              </button>
              <button 
                onClick={() => onShowToast('Loading match statistics...', 'info')}
                className="h-14 px-8 rounded-2xl bg-white/5 border border-white/10 text-white font-bold hover:bg-white/10 transition-all"
              >
                Match Details
              </button>
            </motion.div>
          </div>
        </section>

        {/* Categories / Mobile Tabs */}
        <div className="xl:hidden flex items-center gap-3 overflow-x-auto pb-6 custom-scrollbar no-scrollbar">
          {['All Sports', ...sports.map(s => s.name)].map((cat) => (
            <button 
              key={cat} 
              onClick={() => setActiveSport(cat)}
              className={`px-6 py-3 rounded-2xl whitespace-nowrap text-sm font-bold border transition-all ${
                activeSport === cat ? 'bg-[#39FF14] text-black border-[#39FF14]' : 'bg-white/5 text-gray-400 border-white/10'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Live Matches Section */}
        <section className="mb-12">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-[#39FF14]/10 border border-[#39FF14]/20 flex items-center justify-center">
                <Activity className="w-6 h-6 text-[#39FF14]" />
              </div>
              <div>
                <h2 className="text-2xl font-black tracking-tight">Live Matches</h2>
                <p className="text-sm text-gray-500 font-medium">Currently playing worldwide</p>
              </div>
            </div>
            <button 
              onClick={() => setActiveSport('live')}
              className="group flex items-center gap-2 text-sm font-bold text-gray-400 hover:text-white transition-colors"
            >
              View All Live
              <ChevronRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 min-h-[400px]">
            {filteredLiveMatches.length > 0 ? (
              filteredLiveMatches.map((match, idx) => (
                <MatchCard key={match.id} match={match} priority={idx === 0 && activeSport === 'All Sports'} onAction={onShowToast} />
              ))
            ) : (
              <div className="col-span-full flex flex-col items-center justify-center py-20 text-gray-500">
                <Activity className="w-12 h-12 mb-4 opacity-20" />
                <p className="font-bold">No matches found for this filter</p>
              </div>
            )}
          </div>
        </section>



        {/* Upcoming Matches */}
        <section>
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center text-gray-400">
                <Trophy className="w-6 h-6" />
              </div>
              <div>
                <h2 className="text-2xl font-black tracking-tight">Upcoming</h2>
                <p className="text-sm text-gray-500 font-medium">Scheduled for the next 24 hours</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {['Today', 'Tomorrow', 'This Week'].map((label, i) => (
                <button 
                  key={label}
                  onClick={() => onShowToast(`Schedule for ${label} loading...`, 'info')}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                    i === 0 ? 'bg-white/10 text-white' : 'text-gray-500 hover:text-white'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {filteredUpcomingMatches.length > 0 ? (
              filteredUpcomingMatches.map((match) => (
                <MatchCard key={match.id} match={match} onAction={onShowToast} />
              ))
            ) : (
              <div className="col-span-full text-center py-10 text-gray-500 text-sm italic">
                No upcoming matches found for the current selection.
              </div>
            )}
          </div>
        </section>
      </main>
    </div>
  );
}
