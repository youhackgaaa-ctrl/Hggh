/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Match, Category } from './types';

export const CATEGORIES: Category[] = [
  { id: '1', name: 'All Sports', icon: 'LayoutGrid', count: 24 },
  { id: '2', name: 'Football', icon: 'Trophy', count: 12 },
  { id: '3', name: 'Cricket', icon: 'Activity', count: 8 },
  { id: '4', name: 'Basketball', icon: 'Dribbble', count: 4 },
];

export const LIVE_MATCHES: Match[] = [
  {
    id: 'l1',
    sport: 'Football',
    title: 'Champions League - Final',
    teams: {
      home: { name: 'Real Madrid', logo: 'https://api.dicebear.com/7.x/identicon/svg?seed=RM', score: 2 },
      away: { name: 'Man City', logo: 'https://api.dicebear.com/7.x/identicon/svg?seed=MC', score: 1 },
    },
    status: 'live',
    time: "78'",
    isLive: true,
    viewers: '1.2M',
    league: 'UEFA Champions League'
  },
  {
    id: 'l2',
    sport: 'Cricket',
    title: 'T20 World Cup',
    teams: {
      home: { name: 'India', logo: 'https://api.dicebear.com/7.x/identicon/svg?seed=IND', score: 182 },
      away: { name: 'Australia', logo: 'https://api.dicebear.com/7.x/identicon/svg?seed=AUS', score: 145 },
    },
    status: 'live',
    time: "15.4 Ov",
    isLive: true,
    viewers: '850K',
    league: 'ICC World Cup'
  },
  {
    id: 'l3',
    sport: 'Football',
    title: 'Premier League',
    teams: {
      home: { name: 'Liverpool', logo: 'https://api.dicebear.com/7.x/identicon/svg?seed=LFC', score: 0 },
      away: { name: 'Arsenal', logo: 'https://api.dicebear.com/7.x/identicon/svg?seed=ARS', score: 0 },
    },
    status: 'live',
    time: "12'",
    isLive: true,
    viewers: '420K',
    league: 'Premier League'
  }
];

export const UPCOMING_MATCHES: Match[] = [];
