/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Sport {
  id: string;
  name: string;
  emoji: string;
  color: string;
}

export interface Team {
  name: string;
  logo: string;
  score?: number;
}

export interface Match {
  id: string;
  sport: string;
  title: string;
  teams: {
    home: Team;
    away: Team;
  };
  status: 'live' | 'upcoming' | 'finished';
  time: string;
  isLive: boolean;
  viewers?: string;
  league: string;
  videoUrl?: string;
  scheduledTime?: string;
  isTvChannel?: boolean;
  posterUrl?: string;
}

export interface Category {
  id: string;
  name: string;
  icon: string;
  count: number;
}
