/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Safely parses a datetime-local input string (YYYY-MM-DDTHH:mm) as a local Date object.
 * This avoids cross-browser/cross-platform engine bugs where some parse ISO-8601 strings
 * without a timezone as UTC instead of local time.
 */
export function parseLocalDatetime(datetimeStr: string | undefined): Date {
  if (!datetimeStr) return new Date(NaN);
  
  // Extract all digit sequences (year, month, day, hour, minute, etc.)
  const parts = datetimeStr.match(/\d+/g);
  if (!parts || parts.length < 5) {
    return new Date(NaN);
  }
  
  const year = parseInt(parts[0], 10);
  const month = parseInt(parts[1], 10) - 1; // 0-indexed month
  const day = parseInt(parts[2], 10);
  const hour = parseInt(parts[3], 10);
  const minute = parseInt(parts[4], 10);
  const second = parts[5] ? parseInt(parts[5], 10) : 0;
  
  return new Date(year, month, day, hour, minute, second);
}
