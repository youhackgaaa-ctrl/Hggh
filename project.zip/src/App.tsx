/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useMemo } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import ToastContainer, { Toast } from './components/Toast';
import Home from './pages/Home';
import WatchMatch from './pages/WatchMatch';
import Admin from './pages/Admin';
import { LIVE_MATCHES, UPCOMING_MATCHES } from './data';
import { Match, Sport } from './types';
import { parseLocalDatetime } from './utils';

const DEFAULT_SPORTS: Sport[] = [
  { id: 'Football', name: 'Football', emoji: '⚽', color: '#FFD700' },
  { id: 'Cricket', name: 'Cricket', emoji: '🏏', color: '#39FF14' },
  { id: 'Basketball', name: 'Basketball', emoji: '🏀', color: '#FF4500' },
  { id: 'Tennis', name: 'Tennis', emoji: '🎾', color: '#00D4FF' },
  { id: 'TV Channel', name: 'TV Channel', emoji: '📺', color: '#FF007F' },
];

export default function App() {
  const [searchQuery, setSearchQuery] = useState('');
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [matches, setMatches] = useState<Match[]>(() => {
    const saved = localStorage.getItem('sports_live_matches');
    if (saved) {
      const parsed = JSON.parse(saved) as Match[];
      return parsed.filter(m => m.title !== 'IPL 2026' && m.id !== 'u1' && m.id !== 'u2' && m.title !== 'La Liga');
    }
    return [...LIVE_MATCHES, ...UPCOMING_MATCHES];
  });
  const [sports, setSports] = useState<Sport[]>(() => {
    const saved = localStorage.getItem('sports_live_sports_list');
    if (saved) {
      const parsed = JSON.parse(saved);
      if (!parsed.some((s: any) => s.id === 'TV Channel' || s.name.toLowerCase() === 'tv channel')) {
        const updated = [...parsed, { id: 'TV Channel', name: 'TV Channel', emoji: '📺', color: '#FF007F' }];
        localStorage.setItem('sports_live_sports_list', JSON.stringify(updated));
        return updated;
      }
      return parsed;
    }
    return DEFAULT_SPORTS;
  });

  useEffect(() => {
    localStorage.setItem('sports_live_matches', JSON.stringify(matches));
  }, [matches]);

  useEffect(() => {
    localStorage.setItem('sports_live_sports_list', JSON.stringify(sports));
  }, [sports]);

  // Auto-start scheduled matches when countdown finishes
  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date();
      let hasChanges = false;

      const updatedMatches = matches.map(match => {
        if (!match.isLive && match.scheduledTime) {
          const scheduledDate = parseLocalDatetime(match.scheduledTime);
          // Only auto-start if we successfully parsed the date and now has reached or passed it
          if (!isNaN(scheduledDate.getTime()) && now >= scheduledDate) {
            hasChanges = true;
            return { 
              ...match, 
              isLive: true, 
              status: 'live' as const,
              time: "0'" // Initialize clock at 0' when it goes live automatically
            };
          }
        }
        return match;
      });

      if (hasChanges) {
        setMatches(updatedMatches);
        showToast('A scheduled match has started live!', 'info');
      }
    }, 1000); // Check every 1 second to keep it super snappy

    return () => clearInterval(interval);
  }, [matches]);

  const showToast = (message: string, type: 'success' | 'info' = 'success') => {
    const id = Math.random().toString(36).substr(2, 9);
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3000);
  };

  return (
    <Router>
      <div className="min-h-screen bg-black text-white font-sans selection:bg-[#39FF14] selection:text-black">
        <Routes>
          <Route path="/" element={
            <>
              <Header onSearch={setSearchQuery} onShowToast={showToast} />
              <Home 
                searchQuery={searchQuery} 
                onShowToast={showToast} 
                matches={matches}
                sports={sports}
              />
            </>
          } />
          <Route path="/watch/:id" element={<WatchMatch matches={matches} />} />
          <Route path="/admin" element={
            <>
              <Header onSearch={setSearchQuery} onShowToast={showToast} />
              <Admin 
                matches={matches} 
                setMatches={setMatches} 
                onShowToast={showToast} 
                sports={sports}
                setSports={setSports}
              />
            </>
          } />
        </Routes>

        <ToastContainer toasts={toasts} removeToast={(id) => setToasts(t => t.filter(x => x.id !== id))} />
      </div>
    </Router>
  );
}
