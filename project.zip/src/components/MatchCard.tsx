/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Play, Users, Calendar } from 'lucide-react';
import { motion } from 'motion/react';
import { useNavigate } from 'react-router-dom';
import { Match } from '../types';

interface MatchCardProps {
  match: Match;
  priority?: boolean;
  key?: string | number;
  onAction?: (msg: string) => void;
}

export default function MatchCard({ match, priority = false, onAction }: MatchCardProps) {
  const navigate = useNavigate();

  const handleWatchClick = () => {
    if (match.isLive || match.scheduledTime) {
      onAction?.(`Opening ${match.title} match hub...`);
      navigate(`/watch/${match.id}`);
    }
  };

  const isScheduled = !!match.scheduledTime && !match.isLive;

  return (
    <motion.div
      whileHover={{ y: -5 }}
      onClick={handleWatchClick}
      className={`relative group overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-b from-white/5 to-transparent backdrop-blur-sm cursor-pointer ${
        priority ? 'col-span-full lg:col-span-2 aspect-[16/9]' : 'aspect-[4/5]'
      }`}
    >
      {/* Background Poster Image if configured */}
      {match.posterUrl && (
        <div className="absolute inset-0 z-0">
          <img 
            src={match.posterUrl} 
            alt="" 
            className="w-full h-full object-cover opacity-25 group-hover:opacity-40 transition-opacity duration-500" 
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-black/80" />
        </div>
      )}

      {/* Background Glow */}
      <div className={`absolute inset-0 transition-opacity duration-500 opacity-0 group-hover:opacity-10 ${
        match.isLive ? 'bg-[#39FF14]' : isScheduled ? 'bg-[#00D4FF]' : 'bg-[#00D4FF]'
      }`} />

      {/* Card Content */}
      <div className="absolute inset-0 p-6 flex flex-col justify-between z-10">
        {/* Top Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-black/40 border border-white/10 backdrop-blur-md">
            <span className="text-[10px] font-bold tracking-widest text-gray-400 uppercase">
              {match.league}
            </span>
          </div>
          {match.isLive && (
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#39FF14]/10 border border-[#39FF14]/30 backdrop-blur-md">
              <span className="w-1.5 h-1.5 bg-[#39FF14] rounded-full animate-pulse" />
              <span className="text-[10px] font-bold text-[#39FF14] uppercase tracking-wider">Live</span>
              {match.viewers && (
                <div className="flex items-center gap-1 ml-2 border-l border-white/10 pl-2">
                  <Users className="w-3 h-3 text-white" />
                  <span className="text-[10px] text-white font-medium">{match.viewers}</span>
                </div>
              )}
            </div>
          )}
          {isScheduled && (
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#00D4FF]/10 border border-[#00D4FF]/30 backdrop-blur-md">
              <Calendar className="w-3 h-3 text-[#00D4FF]" />
              <span className="text-[10px] font-bold text-[#00D4FF] uppercase tracking-wider">Upcoming</span>
            </div>
          )}
        </div>

        {/* Center Content: Teams or TV Channel */}
        <div className="flex-1 flex flex-col items-center justify-center gap-8 my-4">
          {match.isTvChannel ? (
            <div className="flex flex-col items-center gap-4">
              <div className="w-20 h-20 md:w-24 md:h-24 rounded-[2rem] bg-white/5 border border-white/10 flex items-center justify-center p-4 relative group-hover:border-[#39FF14]/50 transition-colors shadow-2xl">
                <img 
                  src={match.teams?.home?.logo || "https://api.dicebear.com/7.x/identicon/svg?seed=TV"} 
                  alt={match.title} 
                  className="w-full h-full object-contain" 
                  referrerPolicy="no-referrer" 
                />
                <span className="absolute -top-1.5 -right-1.5 px-2.5 py-0.5 rounded-lg bg-red-600 border border-white/10 text-[9px] font-black tracking-widest uppercase text-white shadow-lg">
                  TV
                </span>
              </div>
              <div className="text-center">
                <h3 className="text-lg font-black text-white group-hover:text-[#39FF14] transition-colors line-clamp-2 px-4 leading-tight">
                  {match.title}
                </h3>
                <span className={`text-[10px] font-bold px-2 py-0.5 mt-2 inline-block rounded-md ${match.isLive ? 'text-[#39FF14] bg-[#39FF14]/10 border border-[#39FF14]/20' : 'text-gray-500 bg-white/5'}`}>
                  {match.isLive ? 'ON AIR' : match.time || 'OFFLINE'}
                </span>
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-between w-full max-w-sm gap-4">
              {/* Home Team */}
              <div className="flex flex-col items-center gap-4 flex-1">
                <div className="w-16 h-16 md:w-20 md:h-20 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center p-3 relative group-hover:border-[#39FF14]/50 transition-colors">
                  <img src={match.teams.home.logo} alt={match.teams.home.name} className="w-full h-full object-contain" referrerPolicy="no-referrer" />
                </div>
                <span className="text-sm font-bold text-white text-center line-clamp-1">{match.teams.home.name}</span>
              </div>

              {/* Score or VS */}
              <div className="flex flex-col items-center gap-2">
                <div className="px-4 py-1 rounded-full bg-white/5 border border-white/10">
                  <span className="text-sm font-black text-gray-400">VS</span>
                </div>
                <span className={`text-xs font-bold px-2 py-1 rounded-md ${match.isLive ? 'text-[#39FF14] bg-[#39FF14]/5' : 'text-gray-500'}`}>
                  {match.time}
                </span>
              </div>

              {/* Away Team */}
              <div className="flex flex-col items-center gap-4 flex-1">
                <div className="w-16 h-16 md:w-20 md:h-20 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center p-3 relative group-hover:border-[#00D4FF]/50 transition-colors">
                  <img src={match.teams.away.logo} alt={match.teams.away.name} className="w-full h-full object-contain" referrerPolicy="no-referrer" />
                </div>
                <span className="text-sm font-bold text-white text-center line-clamp-1">{match.teams.away.name}</span>
              </div>
            </div>
          )}
        </div>

        {/* Bottom Actions */}
        <div className="flex items-center gap-3 mt-auto">
          {match.isLive || isScheduled ? (
            <button 
              onClick={(e) => { e.stopPropagation(); handleWatchClick(); }}
              className={`flex-1 h-12 rounded-2xl font-bold flex items-center justify-center gap-2 transition-all transform active:scale-95 ${
                match.isLive 
                ? "bg-[#39FF14] hover:bg-[#32e012] text-black shadow-[0_0_20px_rgba(57,255,20,0.3)]" 
                : "bg-[#00D4FF] hover:bg-[#00b8e6] text-black shadow-[0_0_20px_rgba(0,212,255,0.3)]"
              }`}
            >
              {match.isLive ? <Play className="w-4 h-4 fill-current" /> : <Calendar className="w-4 h-4" />}
              {match.isLive ? 'Watch Live' : 'View Countdown'}
            </button>
          ) : (
            <button 
              onClick={(e) => { e.stopPropagation(); onAction?.(`Notification set for ${match.title}!`); }}
              className="flex-1 h-12 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 text-white font-bold flex items-center justify-center gap-2 transition-all transform active:scale-95"
            >
              <Calendar className="w-4 h-4" />
              Notify Me
            </button>
          )}
          <button className="w-12 h-12 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 flex items-center justify-center transition-all group-hover:border-white/30">
            <div className="w-1 h-1 bg-white rounded-full mx-0.5" />
            <div className="w-1 h-1 bg-white rounded-full mx-0.5" />
            <div className="w-1 h-1 bg-white rounded-full mx-0.5" />
          </button>
        </div>
      </div>
    </motion.div>
  );
}
