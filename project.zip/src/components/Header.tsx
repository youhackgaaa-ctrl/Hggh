/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Search, Bell, User, Menu, Settings, X } from 'lucide-react';
import { motion } from 'motion/react';
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

interface HeaderProps {
  onSearch: (query: string) => void;
  onShowToast: (msg: string, type?: 'success' | 'info') => void;
}

export default function Header({ onSearch, onShowToast }: HeaderProps) {
  const navigate = useNavigate();

  const handleLogoClick = () => {
    navigate('/');
  };

  return (
    <>
      <header className="fixed top-0 left-0 right-0 z-50 bg-black/80 backdrop-blur-xl border-b border-white/5">
      <div className="max-w-[1600px] mx-auto px-4 md:px-8 h-20 flex items-center justify-between gap-4">
        {/* Logo */}
        <div 
          className="flex items-center gap-3 min-w-fit cursor-pointer group"
          onClick={handleLogoClick}
        >
          <div className="w-10 h-10 bg-gradient-to-br from-[#39FF14] to-[#00D4FF] rounded-xl flex items-center justify-center transition-transform group-active:scale-90">
            <div className="w-6 h-6 bg-black rounded-lg transform rotate-45 flex items-center justify-center overflow-hidden">
              <div className="w-full h-full bg-gradient-to-br from-[#39FF14] to-[#00D4FF] opacity-80" />
            </div>
          </div>
          <span className="text-2xl font-bold tracking-tighter text-white">
            SPORTS<span className="text-[#39FF14]">LIVE</span>
          </span>
        </div>

        {/* Navigation - Desktop */}
        <nav className="hidden lg:flex items-center gap-8">
          {['Home', 'Live', 'Schedules', 'Results', 'News'].map((item) => (
            <button
              key={item}
              onClick={() => onShowToast(`${item} section coming soon`, 'info')}
              className="text-sm font-medium text-gray-400 hover:text-[#39FF14] transition-colors relative group"
            >
              {item}
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-[#39FF14] transition-all group-hover:w-full" />
            </button>
          ))}
        </nav>

        {/* Search & Actions */}
        <div className="flex items-center gap-2 md:gap-4 flex-1 justify-end">
          <div className="flex items-center bg-white/5 border border-white/10 rounded-full px-3 py-1.5 md:px-4 md:py-2 w-full max-w-[120px] xs:max-w-[150px] sm:max-w-[200px] md:max-w-xs focus-within:border-[#39FF14]/50 transition-colors">
            <Search className="w-3.5 h-3.5 md:w-4 md:h-4 text-gray-400 shrink-0" />
            <input
              type="text"
              placeholder="Search..."
              onChange={(e) => onSearch(e.target.value)}
              className="bg-transparent border-none outline-none text-xs md:text-sm text-white pl-2 pr-1 w-full"
            />
          </div>

          <div className="flex items-center gap-1.5 md:gap-2">
            <button 
              onClick={() => onShowToast('No new notifications', 'info')}
              className="p-2 md:p-2.5 rounded-full bg-white/5 border border-white/10 text-white hover:bg-white/10 transition-colors relative"
            >
              <Bell className="w-4 h-4 md:w-5 md:h-5" />
              <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 bg-[#00D4FF] rounded-full" />
            </button>
            <button className="w-8 h-8 md:w-10 md:h-10 rounded-full bg-gradient-to-br from-gray-800 to-gray-900 border border-white/10 flex items-center justify-center text-white overflow-hidden">
              <User className="w-4 h-4 md:w-5 md:h-5 text-gray-400" />
            </button>
            <button className="lg:hidden p-1.5 md:p-2 text-white">
              <Menu className="w-5 h-5 md:w-6 md:h-6" />
            </button>
          </div>
        </div>
      </div>
      </header>
    </>
  );
}
