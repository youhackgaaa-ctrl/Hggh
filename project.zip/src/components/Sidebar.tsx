/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { LayoutGrid, Activity, Clock, Heart } from 'lucide-react';
import { motion } from 'motion/react';
import { Sport } from '../types';

interface SidebarProps {
  activeSport: string;
  onSportChange: (sport: string) => void;
  sports: Sport[];
}

export default function Sidebar({ activeSport, onSportChange, sports }: SidebarProps) {
  const topItems = [
    { id: 'All Sports', label: 'All Sports', icon: LayoutGrid, color: '#39FF14' },
    { id: 'fav', label: 'Favorites', icon: Heart, color: '#FF1493' },
    { id: 'live', label: 'Live Now', icon: Activity, color: '#00D4FF' },
  ];

  const bottomItems = [
    { id: 'upcoming', label: 'Upcoming', icon: Clock, color: '#8A2BE2' },
  ];

  return (
    <aside className="hidden xl:flex flex-col w-72 h-[calc(100vh-80px)] fixed left-0 top-20 border-r border-white/5 bg-black/40 backdrop-blur-sm p-6 overflow-y-auto custom-scrollbar">
      <div className="flex flex-col gap-8">
        <section>
          <h3 className="text-[10px] font-bold text-gray-500 uppercase tracking-[0.2em] mb-6 pl-4">
            Main Menu
          </h3>
          <div className="flex flex-col gap-2">
            {topItems.map((item) => (
              <button
                key={item.id}
                onClick={() => onSportChange(item.id)}
                className={`flex items-center gap-4 px-4 py-3.5 rounded-2xl transition-all group relative overflow-hidden ${
                  activeSport === item.id 
                  ? 'bg-gradient-to-r from-white/10 to-transparent border border-white/10' 
                  : 'hover:bg-white/5'
                }`}
              >
                <item.icon className={`w-5 h-5 transition-colors ${
                  activeSport === item.id ? 'text-white' : 'text-gray-400 group-hover:text-white'
                }`} />
                <span className={`text-sm font-semibold transition-colors ${
                  activeSport === item.id ? 'text-white' : 'text-gray-400 group-hover:text-white'
                }`}>
                  {item.label}
                </span>
                {item.id === 'live' && (
                  <span className="ml-auto w-2 h-2 bg-[#00D4FF] rounded-full shadow-[0_0_8px_rgba(0,212,255,0.6)]" />
                )}
                {activeSport === item.id && (
                  <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-6 bg-[#39FF14] rounded-r-full" />
                )}
              </button>
            ))}

            {sports.map((sport) => (
              <button
                key={sport.id}
                onClick={() => onSportChange(sport.id)}
                className={`flex items-center gap-4 px-4 py-3.5 rounded-2xl transition-all group relative overflow-hidden ${
                  activeSport === sport.id 
                  ? 'bg-gradient-to-r from-white/10 to-transparent border border-white/10' 
                  : 'hover:bg-white/5'
                }`}
              >
                <span className="text-lg w-5 h-5 flex items-center justify-center select-none" style={{ filter: activeSport === sport.id ? 'none' : 'grayscale(20%)' }}>
                  {sport.emoji || '🏆'}
                </span>
                <span className={`text-sm font-semibold transition-colors ${
                  activeSport === sport.id ? 'text-white' : 'text-gray-400 group-hover:text-white'
                }`}>
                  {sport.name}
                </span>
                {activeSport === sport.id && (
                  <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-6 bg-[#39FF14] rounded-r-full" />
                )}
              </button>
            ))}

            {bottomItems.map((item) => (
              <button
                key={item.id}
                onClick={() => onSportChange(item.id)}
                className={`flex items-center gap-4 px-4 py-3.5 rounded-2xl transition-all group relative overflow-hidden ${
                  activeSport === item.id 
                  ? 'bg-gradient-to-r from-white/10 to-transparent border border-white/10' 
                  : 'hover:bg-white/5'
                }`}
              >
                <item.icon className={`w-5 h-5 transition-colors ${
                  activeSport === item.id ? 'text-white' : 'text-gray-400 group-hover:text-white'
                }`} />
                <span className={`text-sm font-semibold transition-colors ${
                  activeSport === item.id ? 'text-white' : 'text-gray-400 group-hover:text-white'
                }`}>
                  {item.label}
                </span>
                {activeSport === item.id && (
                  <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-6 bg-[#39FF14] rounded-r-full" />
                )}
              </button>
            ))}
          </div>
        </section>

        <section>
          <h3 className="text-[10px] font-bold text-gray-500 uppercase tracking-[0.2em] mb-6 pl-4">
            Top Leagues
          </h3>
          <div className="flex flex-col gap-3">
            {[
              { name: 'Champions League', icon: '🏆' },
              { name: 'Premier League', icon: '🏴󠁧󠁢󠁥󠁮󠁧󠁿' },
              { name: 'IPL 2026', icon: '🏏' },
              { name: 'NBA Playoffs', icon: '🏀' },
            ].map((league) => (
              <button key={league.name} className="flex items-center gap-4 px-4 py-3 rounded-2xl hover:bg-white/5 text-gray-400 hover:text-white transition-all group">
                <span className="text-lg">{league.icon}</span>
                <span className="text-sm font-medium">{league.name}</span>
              </button>
            ))}
          </div>
        </section>

        <div className="mt-auto pt-6 border-t border-white/5">
          <div className="p-4 rounded-3xl bg-gradient-to-br from-[#39FF14]/10 to-transparent border border-[#39FF14]/20">
            <h4 className="text-sm font-bold text-white mb-2">Premium Access</h4>
            <p className="text-xs text-gray-400 leading-relaxed mb-4">
              Get unlimited 4K streaming and zero ads.
            </p>
            <button className="w-full py-2.5 rounded-xl bg-[#39FF14] text-black text-xs font-bold shadow-[0_0_15px_rgba(57,255,20,0.2)]">
              Upgrade Now
            </button>
          </div>
        </div>
      </div>
    </aside>
  );
}
